#include<stdio.h>

int main()
{
    // Local variables
    int No1 = 10;
    int No2 = 11;
    int Ans = 0;

    Ans = No1 + No2;

    printf("%d",Ans);   // 21

    return 0;
}
