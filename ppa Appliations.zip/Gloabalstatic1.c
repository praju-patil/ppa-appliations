#include<stdio.h>

extern int A;

extern int B;

int main()
{
    printf("%d\n",A);

    printf("%d\n",B);

    return 0;
}