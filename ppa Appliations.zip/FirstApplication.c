#include<stdio.h>

int main()
{
    printf("Jay Ganesh...\n");

    return 0;
}

                        gcc     FirstProgram.c      -o      Myexe




                        ./Myexe                 Linux / MacOS

                        Myexe                   Windows