#include<stdio.h>

int main()
{


    int No1 = 10;
    int No2 = 20;
    int No3 = 30;
    int No4 = 40;
    int No5 = 50;

    // Arr is one dimentional array which contains 5 elements each element is of type integer
    int Arr[5] = {10,20,30,40,50};










        printf("%d",Arr[0]);        // 10


    return 0;
}