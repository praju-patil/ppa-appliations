#define ROI 10.7
#define FEES 18200

struct Demo
{
    int i;
    float f;
};